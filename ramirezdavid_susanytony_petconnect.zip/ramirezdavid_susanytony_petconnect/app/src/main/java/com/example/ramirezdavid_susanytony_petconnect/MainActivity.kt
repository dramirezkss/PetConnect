package com.example.ramirezdavid_susanytony_petconnect

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MenuNavegacion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnFeed = findViewById<Button>(R.id.btnFeed)
        val btnProfile = findViewById<Button>(R.id.btnProfile)
        val btnPreferences = findViewById<Button>(R.id.btnPreferences)
        val btnFaq = findViewById<Button>(R.id.btnFaq)
        val btnPostDetail = findViewById<Button>(R.id.btnPostDetail)
        val btnCreatePost = findViewById<Button>(R.id.btnCreatePost)
        val btnChat = findViewById<Button>(R.id.btnChat)

        btnLogin.setOnClickListener { view: View? -> }

        btnFeed.setOnClickListener { view: View? -> }

        btnProfile.setOnClickListener { view: View? -> }

        btnPreferences.setOnClickListener { view: View? -> }

        btnFaq.setOnClickListener { view: View? -> }

        btnPostDetail.setOnClickListener { view: View? -> }

        btnCreatePost.setOnClickListener { view: View? -> }

        btnChat.setOnClickListener { view: View? -> }
    }
}