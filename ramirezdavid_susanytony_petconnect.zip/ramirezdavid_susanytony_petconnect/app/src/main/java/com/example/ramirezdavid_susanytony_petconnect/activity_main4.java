package com.example.ramirezdavid_susanytony_petconnect;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class activity_main4 extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
    }
}